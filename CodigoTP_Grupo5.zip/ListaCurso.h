#pragma once
#include "Curso.h"
#include "Lista.h"

class ListaCurso : public Lista<Curso<float>>
{
private:
public:
	ListaCurso() : Lista() {
	};
	~ListaCurso() {};

	template<typename T>
	Nodo<T>* buscarNodo(Nodo<T>* aux) {
		bool resultado = false;
		int n;
		Nodo<T>* actual = new Nodo<T>();
		actual = primero;
		if (actual != nullptr)
		{
			while (actual != nullptr && resultado != true)
			{
				if (actual->dato.titulo == aux->dato.titulo)
				{
					resultado = true;
					aux = actual;
				}
				actual = actual->siguiente;
			}
			if (resultado == false)
			{
				cout << "El curso " << aux->dato.titulo << " no se ha encontrado" << endl;
				_getch();
				return primero;
			}
			else
			{
				return aux;
			}
		}
	}
	//ORDENAMIENTO RECURSIVO
	void Quicksort(vector<Curso<float>>& v, int inicio, int fin, int n) {
		if (inicio < fin) {
			auto f1 = [&]() {
				Curso<float> aux;
				int pivote = v[inicio].costo;
				int i = inicio + 1;
				for (int j = i; j <= fin; j++) {
					if (n == 1)
					{
						if (v[j].costo < pivote) { aux = v[i]; v[i] = v[j]; v[j] = aux; i++; }
					}
					else if (n == 2)
					{
						if (v[j].costo > pivote) { aux = v[i]; v[i] = v[j]; v[j] = aux; i++; }
					}

				}
				aux = v[inicio];
				v[inicio] = v[i - 1];
				v[i - 1] = aux;
				return i - 1;
			};
			int pivote = f1();
			Quicksort(v, inicio, pivote - 1, n);
			Quicksort(v, pivote + 1, fin, n);
		}
	}
	Nodo<Curso<float>>* Ordenamiento(int n) {
		vector<Curso<float>>vc;
		int i = 0;
		Nodo<Curso<float>>* actual = new Nodo<Curso<float>>();
		actual = primero;
		while (actual != nullptr)
		{
			vc.push_back(actual->dato);
			actual = actual->siguiente;
		}
		actual = primero;
		switch (n)
		{
		case 1:
			Quicksort(vc, 0, vc.size() - 1, n);
			while (actual != nullptr)
			{
				actual->dato = vc[i];
				actual = actual->siguiente;
				i++;
			}
			break;
		case 2:
			Quicksort(vc, 0, vc.size() - 1, n);
			while (actual != nullptr)
			{
				actual->dato = vc[i];
				actual = actual->siguiente;
				i++;
			}
			break;
		default:
			break;
		}
		return actual;
	}

};