#pragma once
#include "Librerias.h"
template<typename T>
struct Empleo
{
    string empresa;
    string puesto_trabajo;
    string descripcion;
    string funcion;
    string ubicacion;
    T sueldo;
};
