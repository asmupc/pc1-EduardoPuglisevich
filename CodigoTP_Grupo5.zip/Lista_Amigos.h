#pragma once
#include "Librerias.h"
#include "Lista.h"

class Lista_Amigos:public Lista<string> {

private:
public:
    Lista_Amigos():Lista() {}
    ~Lista_Amigos() {}
    void Imprimir_Adelante() {

        Nodo<string>* actual = new Nodo<string>();

        actual = primero; //inicializando el recorrido
        if (primero != nullptr) {

            while (actual != nullptr) {


                cout << actual->dato << "\n";


                actual = actual->siguiente; //nos permite cambiar de nodo a nodo

            }

        }
        else {
            cout << "La lista esta vacia";
        }

    }
};