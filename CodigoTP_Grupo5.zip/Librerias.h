#pragma once
#include<iostream>
#include<iomanip>
#include<conio.h>
#include<string>
#include<math.h>
#include<time.h>
#include <stdlib.h>
#include<stdio.h>
#include <vector>
#include <fstream>
using namespace std;
using namespace System;

