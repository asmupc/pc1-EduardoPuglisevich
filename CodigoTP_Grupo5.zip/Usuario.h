#pragma once
#include "Librerias.h"
struct Usuario
{
    string nombre;
    string correo;
    string contrasena;
    string profesion;
    string telefono;
    int edad;
    int id;
};