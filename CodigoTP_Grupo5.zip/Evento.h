#pragma once
#include "Librerias.h"

struct Evento
{
    string nombre_evento;
    string tema;
    string fecha;
    string direccion;
    string descripcion;
};
