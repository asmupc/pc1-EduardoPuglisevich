#pragma once
#include "Evento.h"
#include "Lista.h"
class ColaEvento: public Lista<Evento>
{
private:
	Nodo<Evento>* frente;
	Nodo<Evento>* fin;
public:
	ColaEvento() : Lista() {
		frente = nullptr;
		fin = nullptr;
		primero = frente;
		ultimo = fin;
	};
	~ColaEvento() {};
	template<typename T>
	Nodo<T>* buscarNodo(Nodo<T>* aux) {
		bool resultado = false;
		int n;
		Nodo<T>* actual = new Nodo<T>();
		actual = primero;
		if (actual != nullptr)
		{
			while (actual != nullptr && resultado != true)
			{
				if (actual->dato.nombre_evento == aux->dato.nombre_evento)
				{
					resultado = true;
					aux = actual;
				}
				actual = actual->siguiente;
			}
			if (resultado == false)
			{
				cout << "El evento " << aux->dato.nombre_evento << " no se ha encontrado" << endl;
				_getch();
				return primero;
			}
			else
			{
				return aux;
			}
		}
	}
	bool colaVacia() {

		if (primero == nullptr) {
			return true;
		}
		else {
			return false;
		}
	}
	template<typename T>
	Nodo<T>* EliminarEvento(Nodo<T>* aux) {
		aux = primero;
		if (primero == ultimo) {
			primero = nullptr;
			ultimo = nullptr;
		}
		else {

			primero = primero->siguiente;
			primero->anterior = nullptr;
		}
		delete aux;
		return primero;
	}
};