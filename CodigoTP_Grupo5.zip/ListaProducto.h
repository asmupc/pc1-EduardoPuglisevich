#pragma once
#include "Producto.h"
#include "Lista.h"
class ListaProducto : public Lista<Producto<float>>
{
private:
public:
	ListaProducto() :Lista() {
	};
	~ListaProducto() {};
	template<typename T>
	Nodo<T>* buscarNodo(Nodo<T>* aux) {
		bool resultado = false;
		int n;
		Nodo<T>* actual = new Nodo<T>();
		actual = primero;
		if (actual != nullptr)
		{
			while (actual != nullptr && resultado != true)
			{
				if (actual->dato.nombre_producto == aux->dato.nombre_producto)
				{
					resultado = true;
					aux = actual;
				}
				actual = actual->siguiente;
			}
			if (resultado == false)
			{
				cout << "El producto " << aux->dato.nombre_producto << " no se ha encontrado" << endl;
				_getch();
				return primero;
			}
			else
			{
				return aux;
			}
		}
	}

	//ORDENAMIENTO RECURSIVO
	void Quicksort(vector<Producto<float>>& v, int inicio, int fin, int n) {
		if (inicio < fin) {
			auto f1 = [&]() {
				Producto<float> aux;
				int pivote = v[inicio].costo;
				int i = inicio + 1;
				for (int j = i; j <= fin; j++) {
					if (n == 1)
					{
						if (v[j].costo < pivote) { aux = v[i]; v[i] = v[j]; v[j] = aux; i++; }
					}
					else if (n == 2)
					{
						if (v[j].costo > pivote) { aux = v[i]; v[i] = v[j]; v[j] = aux; i++; }
					}

				}
				aux = v[inicio];
				v[inicio] = v[i - 1];
				v[i - 1] = aux;
				return i - 1;
			};
			int pivote = f1();
			Quicksort(v, inicio, pivote - 1, n);
			Quicksort(v, pivote + 1, fin, n);
		}
	}
	Nodo<Producto<float>>* Ordenamiento(int n) {
		vector<Producto<float>>vp;
		int i = 0;
		Nodo<Producto<float>>* actual = new Nodo<Producto<float>>();
		actual = primero;
		while (actual != nullptr)
		{
			vp.push_back(actual->dato);
			actual = actual->siguiente;
		}
		actual = primero;
		switch (n)
		{
		case 1:
			Quicksort(vp, 0, vp.size() - 1, n);
			while (actual != nullptr)
			{
				actual->dato = vp[i];
				actual = actual->siguiente;
				i++;
			}
			break;
		case 2:
			Quicksort(vp, 0, vp.size() - 1, n);
			while (actual != nullptr)
			{
				actual->dato = vp[i];
				actual = actual->siguiente;
				i++;
			}
			break;
		default:
			break;
		}
		return actual;
	}

};