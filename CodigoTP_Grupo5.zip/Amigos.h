#pragma once

#include "Lista_amigos.h"

void Amigos(string t) {

	ifstream archivo_amig;
	string linea;
	Lista_Amigos lis;

	archivo_amig.open(t, ios::in);
	if (archivo_amig.is_open()) {
		while (!archivo_amig.eof()) {
			getline(archivo_amig, linea);
			lis.agregarDato(linea);
		}

		lis.Imprimir_Adelante();
		archivo_amig.close();
	}
	else {
		cout << "Error";
	}



}
