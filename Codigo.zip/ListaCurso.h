#pragma once
#include "Curso.h"
struct NodoCurso
{
	Curso<float> curso;
	NodoCurso* siguiente;
	NodoCurso* anterior;
};
class ListaCurso
{
private:
	NodoCurso* primero;
	NodoCurso* ultimo;
public:
	ListaCurso() {
		primero = nullptr;
		ultimo = nullptr;
	};
	~ListaCurso() {};

	void agregarCurso(Curso<float> c) {
		NodoCurso* nodoNuevo = new NodoCurso();
		nodoNuevo->curso = c;
		if (primero == nullptr)
		{
			primero = nodoNuevo;
			primero->siguiente = nullptr;
			primero->anterior = nullptr;
			ultimo = primero;
		}
		else
		{
			ultimo->siguiente = nodoNuevo;
			nodoNuevo->siguiente = nullptr;
			nodoNuevo->anterior = ultimo;
			ultimo = nodoNuevo;
		}
	}
	NodoCurso* buscarNodo(NodoCurso* aux) {
		bool resultado = false;
		int n;
		Curso<float> c;
		NodoCurso* actual = new NodoCurso();
		actual = primero;
		if (actual != nullptr)
		{

			while (actual != nullptr && resultado != true)
			{
				if (actual->curso.titulo == aux->curso.titulo)
				{
					resultado = true;
					aux = actual;
				}
				actual = actual->siguiente;
			}
			if (resultado == false)
			{
				cout << "El curso " << aux->curso.titulo << " no se ha encontrado" << endl;
				_getch();
				return primero;
			}
			else
			{
				return aux;
			}
		}
	}
	NodoCurso* NodoSiguiente(NodoCurso* aux) {
		if (aux->siguiente != nullptr)
		{
			return aux->siguiente;
		}
		else
		{
			return aux;
		}
	}
	NodoCurso* NodoAnterior(NodoCurso* aux) {
		if (aux->anterior != nullptr)
		{
			return aux->anterior;
		}
		else
		{
			return aux;
		}
	}

	//ORDENAMIENTO RECURSIVO
	void Quicksort(vector<Curso<float>>& v, int inicio, int fin, int n) {
		if (inicio < fin) {
			auto f1 = [&]() {
				Curso<float> aux;
				int pivote = v[inicio].costo;
				int i = inicio + 1;
				for (int j = i; j <= fin; j++) {
					if (n == 1)
					{
						if (v[j].costo < pivote) { aux = v[i]; v[i] = v[j]; v[j] = aux; i++; }
					}
					else if (n == 2)
					{
						if (v[j].costo > pivote) { aux = v[i]; v[i] = v[j]; v[j] = aux; i++; }
					}

				}
				aux = v[inicio];
				v[inicio] = v[i - 1];
				v[i - 1] = aux;
				return i - 1;
			};
			int pivote = f1();
			Quicksort(v, inicio, pivote - 1, n);
			Quicksort(v, pivote + 1, fin, n);
		}
	}
	NodoCurso* Ordenamiento(int n) {
		vector<Curso<float>>vc;
		int i = 0;
		NodoCurso* actual = new NodoCurso();
		actual = primero;
		while (actual != nullptr)
		{
			vc.push_back(actual->curso);
			actual = actual->siguiente;
		}
		actual = primero;
		switch (n)
		{
		case 1:
			Quicksort(vc, 0, vc.size() - 1, n);
			while (actual != nullptr)
			{
				actual->curso = vc[i];
				actual = actual->siguiente;
				i++;
			}
			break;
		case 2:
			Quicksort(vc, 0, vc.size() - 1, n);
			while (actual != nullptr)
			{
				actual->curso = vc[i];
				actual = actual->siguiente;
				i++;
			}
			break;
		default:
			break;
		}
		return actual;
	}

	bool hayElementos() {
		if (primero == nullptr)
		{
			return false;
		}
		else
		{
			return true;
		}

	}
};