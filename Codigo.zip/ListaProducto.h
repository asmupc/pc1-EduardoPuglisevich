#pragma once
#include "Producto.h"
struct NodoProducto
{
	Producto<float> producto;
	NodoProducto* siguiente;
	NodoProducto* anterior;
};
class ListaProducto
{
private:
	NodoProducto* primero;
	NodoProducto* ultimo;
public:
	ListaProducto() {
		primero = nullptr;
		ultimo = nullptr;
	};
	~ListaProducto() {};

	void agregarProducto(Producto<float> p) {
		NodoProducto* nodoNuevo = new NodoProducto();
		nodoNuevo->producto = p;
		if (primero == nullptr)
		{
			primero = nodoNuevo;
			primero->siguiente = nullptr;
			primero->anterior = nullptr;
			ultimo = primero;
		}
		else
		{
			ultimo->siguiente = nodoNuevo;
			nodoNuevo->siguiente = nullptr;
			nodoNuevo->anterior = ultimo;
			ultimo = nodoNuevo;
		}
	}
	NodoProducto* buscarNodo(NodoProducto* aux) {
		bool resultado = false;
		int n;
		Producto<float> p;
		NodoProducto* actual = new NodoProducto();
		actual = primero;
		if (actual != nullptr)
		{

			while (actual != nullptr && resultado != true)
			{
				if (actual->producto.nombre_producto == aux->producto.nombre_producto)
				{
					resultado = true;
					aux = actual;
				}
				actual = actual->siguiente;
			}
			if (resultado == false)
			{
				cout << "El producto " << aux->producto.nombre_producto << " no se ha encontrado" << endl;
				_getch();
				return primero;
			}
			else
			{
				return aux;
			}
		}
	}
	NodoProducto* NodoSiguiente(NodoProducto* aux) {
		if (aux->siguiente != nullptr)
		{
			return aux->siguiente;
		}
		else
		{
			return aux;
		}
	}
	NodoProducto* NodoAnterior(NodoProducto* aux) {
		if (aux->anterior != nullptr)
		{
			return aux->anterior;
		}
		else
		{
			return aux;
		}
	}

	//ORDENAMIENTO RECURSIVO
	void Quicksort(vector<Producto<float>>& v, int inicio, int fin, int n) {
		if (inicio < fin) {
			auto f1 = [&]() {
				Producto<float> aux;
				int pivote = v[inicio].costo;
				int i = inicio + 1;
				for (int j = i; j <= fin; j++) {
					if (n == 1)
					{
						if (v[j].costo < pivote) { aux = v[i]; v[i] = v[j]; v[j] = aux; i++; }
					}
					else if (n == 2)
					{
						if (v[j].costo > pivote) { aux = v[i]; v[i] = v[j]; v[j] = aux; i++; }
					}

				}
				aux = v[inicio];
				v[inicio] = v[i - 1];
				v[i - 1] = aux;
				return i - 1;
			};
			int pivote = f1();
			Quicksort(v, inicio, pivote - 1, n);
			Quicksort(v, pivote + 1, fin, n);
		}
	}
	NodoProducto* Ordenamiento(int n) {
		vector<Producto<float>>vp;
		int i = 0;
		NodoProducto* actual = new NodoProducto();
		actual = primero;
		while (actual != nullptr)
		{
			vp.push_back(actual->producto);
			actual = actual->siguiente;
		}
		actual = primero;
		switch (n)
		{
		case 1:
			Quicksort(vp, 0, vp.size() - 1, n);
			while (actual != nullptr)
			{
				actual->producto = vp[i];
				actual = actual->siguiente;
				i++;
			}
			break;
		case 2:
			Quicksort(vp, 0, vp.size() - 1, n);
			while (actual != nullptr)
			{
				actual->producto = vp[i];
				actual = actual->siguiente;
				i++;
			}
			break;
		default:
			break;
		}
		return actual;
	}

	bool hayElementos() {
		if (primero == nullptr)
		{
			return false;
		}
		else
		{
			return true;
		}

	}
};