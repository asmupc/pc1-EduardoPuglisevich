#pragma once
#include "Empleo.h"
struct NodoEmpleo
{
	Empleo<int> empleo;
	NodoEmpleo* siguiente;
	NodoEmpleo* anterior;
};
class ListaEmpleo
{
private:
	NodoEmpleo* primero;
	NodoEmpleo* ultimo;
public:
	ListaEmpleo() {
		primero = nullptr;
		ultimo = nullptr;
	};
	~ListaEmpleo() {};

	void agregarEmpleo(Empleo<int> e) {
		NodoEmpleo* nodoNuevo = new NodoEmpleo();
		nodoNuevo->empleo = e;
		if (primero == nullptr)
		{
			primero = nodoNuevo;
			primero->siguiente = nullptr;
			primero->anterior = nullptr;
			ultimo = primero;
		}
		else
		{
			ultimo->siguiente = nodoNuevo;
			nodoNuevo->siguiente = nullptr;
			nodoNuevo->anterior = ultimo;
			ultimo = nodoNuevo;
		}
	}
	NodoEmpleo* buscarNodo(NodoEmpleo* aux) {
		bool resultado = false;
		int n;
		Empleo<int> e;
		NodoEmpleo* actual = new NodoEmpleo();
		actual = primero;
		if (actual != nullptr)
		{

			while (actual != nullptr && resultado != true)
			{
				if (actual->empleo.puesto_trabajo == aux->empleo.puesto_trabajo)
				{
					resultado = true;
					aux = actual;
				}
				actual = actual->siguiente;
			}
			if (resultado == false)
			{
				cout << "El empleo " << aux->empleo.puesto_trabajo << " no se ha encontrado" << endl;
				_getch();
				return primero;
			}
			else
			{
				return aux;
			}
		}
	}
	NodoEmpleo* NodoSiguiente(NodoEmpleo* aux) {
		if (aux->siguiente != nullptr)
		{
			return aux->siguiente;
		}
		else
		{
			return aux;
		}
	}
	NodoEmpleo* NodoAnterior(NodoEmpleo* aux) {
		if (aux->anterior != nullptr)
		{
			return aux->anterior;
		}
		else
		{
			return aux;
		}
	}

	//ORDENAMIENTO RECURSIVO
	void Quicksort(vector<Empleo<int>>& v, int inicio, int fin, int n) {
		if (inicio < fin) {
			auto f1 = [&]() { 
			Empleo<int> aux;
			int pivote = v[inicio].sueldo;
			int i = inicio + 1;
			for (int j = i; j <= fin; j++) {
				if (n == 1)
				{
					if (v[j].sueldo < pivote) { aux = v[i]; v[i] = v[j]; v[j] = aux; i++; }
				}
				else if (n == 2)
				{
					if (v[j].sueldo > pivote) { aux = v[i]; v[i] = v[j]; v[j] = aux; i++; }
				}

			}
			aux = v[inicio];
			v[inicio] = v[i - 1];
			v[i - 1] = aux;
			return i - 1;
			};
			int pivote = f1();
			Quicksort(v, inicio, pivote - 1, n);
			Quicksort(v, pivote + 1, fin, n);
		}
	}
	NodoEmpleo* Ordenamiento(int n) {
		vector<Empleo<int>>ve;
		int i = 0;
		NodoEmpleo* actual = new NodoEmpleo();
		actual = primero;
		while (actual != nullptr)
		{
			ve.push_back(actual->empleo);
			actual = actual->siguiente;
		}
		actual = primero;
		switch (n)
		{
		case 1:
			Quicksort(ve, 0, ve.size() - 1, n);
			while (actual != nullptr)
			{
				actual->empleo = ve[i];
				actual = actual->siguiente;
				i++;
			}
			break;
		case 2:
			Quicksort(ve, 0, ve.size() - 1, n);
			while (actual != nullptr)
			{
				actual->empleo = ve[i];
				actual = actual->siguiente;
				i++;
			}
			break;
		default:
			break;
		}
		return actual;
	}

	bool hayElementos() {
		if (primero == nullptr)
		{
			return false;
		}
		else
		{
			return true;
		}

	}
};