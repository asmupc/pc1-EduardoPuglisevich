#pragma once
#include "Librerias.h"
struct NodoAmigos {

    string valor;
    NodoAmigos* siguiente;
    NodoAmigos* anterior;
};

class Lista_Amigos {

private:
    NodoAmigos* inicio;
    NodoAmigos* fin;
public:
    Lista_Amigos() {
        inicio = nullptr;
        fin = nullptr;

    }
    ~Lista_Amigos() {}
    void Inserta(string v) {

        NodoAmigos* nuevo = new NodoAmigos();

        nuevo->valor = v;

        //cuando no hay datos en la lista, inicio y fin apuntan a null
        if (inicio == nullptr) {
            inicio = nuevo;
            inicio->siguiente = nullptr;
            inicio->anterior = nullptr;
            fin = inicio;
        }
        else {
            fin->siguiente = nuevo;
            nuevo->siguiente = nullptr;
            nuevo->anterior = fin;
            fin = nuevo;
        }
        cout << endl;
    }
    void Imprimir_Adelante() {

        NodoAmigos* actual = new NodoAmigos();
        //Nodo<T>* actual = new Nodo();
        actual = inicio; //inicializando el recorrido
        if (inicio != nullptr) {

            while (actual != nullptr) {


                cout << actual->valor << "\n";


                actual = actual->siguiente; //nos permite cambiar de nodo a nodo

            }

        }
        else {
            cout << "La lista esta vacia";
        }

    }
};