#include "Usuario.h"
class VectorUsuario
{
private:
	vector<Usuario>vectorU;
public:
	VectorUsuario() {
	};
	~VectorUsuario() {};

	void agregarUsuario(Usuario u) {
		vectorU.push_back(u);
	}

	bool comprobarAutenticidad(Usuario auxU) {
		int aux;
		bool validacion = false;
		for (int i = 0; i < vectorU.size(); i++)
		{
			if (vectorU[i].correo == auxU.correo && vectorU[i].contrasena == auxU.contrasena)
			{
				validacion = true;
				aux = i;
			}
		}
		if (validacion == true)
		{
			cout << "BIENVENIDO " << vectorU[aux].nombre << endl;
		}
		else
		{
			cout << "Correo electronico o contrase�a incorrecta" << endl;
		}
		cout << "Presion cualquier tecla para continuar" << endl;
		getch();
		return validacion;
	}

	int buscarPersona(Usuario auxU) {
		bool resultado = false;
		for (int i = 0; i < vectorU.size(); i++)
		{
			if (vectorU[i].nombre == auxU.nombre)
			{
				resultado = true;
				return i;
			}
		}
		if (resultado == false)
		{
			cout << "La persona " << auxU.nombre << " no se ha encontrado" << endl;
			_getch();
			return 0;
		}
	}

	Usuario getUsuarioActivo(Usuario auxU) {
		for (int i = 0; i < vectorU.size(); i++)
		{
			if (vectorU[i].correo == auxU.correo && vectorU[i].contrasena == auxU.contrasena)
			{
				return vectorU[i];
			}
		}
	}

	Usuario getUsuario(int pos) {
		return vectorU[pos];
	}

	int getTamanio() {
		return vectorU.size();
	}
	void limpiar() {
		vectorU.clear();
	}
};