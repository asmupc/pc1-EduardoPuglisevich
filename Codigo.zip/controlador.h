#pragma once
#include "VectorUsuario.h"
#include "ListaEmpleo.h"
#include "ListaCurso.h"
#include "Amigos.h"
#include "ListaProducto.h"
#include "ListaEvento.h"

class Controlador
{
private:
	VectorUsuario* vectorU;
	ListaEmpleo* ListaE;
	ListaCurso* ListaC;
	Lista_Amigos* ListaA;
	ListaProducto* ListaP;
	ListaEvento* ListaEV;
	Usuario u;
	Usuario activo;
	Empleo<int> e;
	Curso<float> c;
	Producto<float> p;
	Evento ev;
	NodoEmpleo* nodoE;
	NodoCurso* nodoC;
	NodoProducto* nodoP;
	NodoEvento* nodoEV;
	ofstream salida;
	ifstream entrada;
public:
	Controlador() {
		vectorU = new VectorUsuario();
		vectorU->limpiar();
	};
	~Controlador() {};

	void signUp() {
		int cont = 1;
		Console::Clear();
		salida.open("registro.dat", ios::out | ios::app | ios::binary);
		if (salida.is_open()) {
			cout << "--------- REGISTRO DE CUENTA ---------" << endl;
			cin.ignore(10000,'\n');
			cout << " Ingrese su nombre: ";
			getline(cin, u.nombre);
			cout << " Ingrese su edad: ";
			cin >> u.edad;
			cin.ignore(10000,'\n');
			cout << " Ingrese su profesi�n: ";
			getline(cin, u.profesion);
			cout << " Ingrese su n�mero de telefono: ";
			getline(cin, u.telefono);
			cout << " Ingrese su correo: ";
			getline(cin, u.correo);
			cout << " Ingrese su contrase�a: ";
			getline(cin, u.contrasena);
			u.id = cont;
			cont++;

			salida.write((const char*)&u, sizeof(Usuario));
			salida.close();
		}
		else
		{
			cout << "ERROR" << endl;
		}
	}
	bool Login() {
		bool validacion;
		Usuario auxU;
		int cont = 1;
		entrada.open("registro.dat", ios::in | ios::binary);
		if (entrada.is_open()) {
			while (!entrada.eof())
			{
				entrada.read((char*)&u, sizeof(Usuario));
				u.id = cont;
				vectorU->agregarUsuario(u);
				cont++;
			}
			entrada.close();
		}
		Console::Clear();
		cout << "--------- INICIO DE SESION ---------" << endl;
		cin.ignore(10000,'\n');
		cout << "Ingrese su correo: ";
		getline(cin, auxU.correo);
		cout << "Ingrese su contrase�a: ";
		getline(cin, auxU.contrasena);
		validacion = vectorU->comprobarAutenticidad(auxU);
		if (validacion == true)
		{
			activo = vectorU->getUsuarioActivo(auxU);
		}
		return validacion;
	}

	void Implementar_Amigos() {
		Console::Clear();
		string arl[6] = { "-","Amigos.txt","Amigos2.txt","Amigos3.txt","Amigos4.txt","Amigos5.txt" };
		for (int i = 1; i <= 5; ++i) {
			if (activo.id == i) {
				Amigos(arl[i]);
			}
		}
	}

	void publicarCurso() {
		Console::Clear();
		salida.open("cursos.dat", ios::out | ios::app | ios::binary);
		if (salida.is_open()) {
			cout << "--------- PUBLICACI�N DE CURSO ---------" << endl;
			cin.ignore(10000,'\n');
			cout << " Ingrese el tema del curso: ";
			getline(cin, c.tema);
			cout << " Ingrese el titulo del curso: ";
			getline(cin, c.titulo);
			cout << " Ingrese el nombre del profesor: ";
			getline(cin, c.profesor);
			cout << " Ingrese la fecha de publicacion del curso: ";
			getline(cin, c.fecha_publicacion);
			cout << " Ingrese el costo del curso: ";
			cin >> c.costo;
			cin.ignore(10000, '\n');
			salida.write((const char*)&c, sizeof(Curso<float>));
			salida.close();
		}
		else
		{
			cout << "ERROR" << endl;
		}
	}
	void publicarEmpleo() {
		Console::Clear();
		salida.open("empleos.dat", ios::out | ios::app | ios::binary);
		if (salida.is_open()) {
			cout << "--------- PUBLICACI�N DE EMPLEO ---------" << endl;
			cin.ignore(10000,'\n');
			cout << " Ingrese el puesto de trabajo: ";
			getline(cin, e.puesto_trabajo);
			cout << " Ingrese el nombre de la empresa: ";
			getline(cin, e.empresa);
			cout << " Ingrese la ubicacion donde se realizara el trabajo: ";
			getline(cin, e.ubicacion);
			cout << " Ingrese una peque�a descripci�n del puesto de trabajo: ";
			getline(cin, e.descripcion);
			cout << " Ingrese la funcion laboral que se debe realizar: ";
			getline(cin, e.funcion);
			cout << " Ingrese el sueldo que se ganara en su puesto de trabajo:";
			cin >> e.sueldo;
			cin.ignore(10000, '\n');
			salida.write((const char*)&e, sizeof(Empleo<int>));
			salida.close();
		}
		else
		{
			cout << "ERROR" << endl;
		}
	}
	void publicarProducto() {
		Console::Clear();
		salida.open("producto.dat", ios::out | ios::app | ios::binary);
		if (salida.is_open()) {
			cout << "--------- PUBLICACI�N DE PRODUCTO ---------" << endl;
			cin.ignore(10000,'\n');
			cout << " Ingrese el nombre del producto: ";
			getline(cin, p.nombre_producto);
			cout << " Ingrese el nombre de la empresa: ";
			getline(cin, p.nombre_empresa);
			cout << " Ingrese una breve descripcion: ";
			getline(cin,p.descripcion);
			cout << " Ingrese el costo del producto: ";
			cin >> p.costo;
			cin.ignore(10000, '\n');
			salida.write((const char*)&p, sizeof(Producto<float>));
			salida.close();
		}
		else
		{
			cout << "ERROR" << endl;
		}
	}
	void publicarEvento() {
		Console::Clear();
		salida.open("evento.dat", ios::out | ios::app | ios::binary);
		if (salida.is_open()) {
			cout << "--------- PUBLICACI�N DE EVENTO ---------" << endl;
			cout << " Ingrese el nombre del evento: ";
			cin >> ev.nombre_evento;
			cout << " Ingrese el tema del evento: ";
			cin >> ev.tema;
			cout << " Ingrese la fecha del evento: ";
			cin >> ev.fecha;
			cout << " Ingrese la direccion del evento: ";
			cin >> ev.direccion;
			cout << " Ingrese una breve descripcion del evento: ";
			cin >> ev.descripcion;
			salida.write((const char*)&ev, sizeof(Evento));
			salida.close();
		}
		else
		{
			cout << "ERROR" << endl;
		}
	}

	void buscarEmpleo() {
		ListaE = new ListaEmpleo();
		NodoEmpleo* aux = new NodoEmpleo();
		bool finalizar = false;
		int op;
		entrada.open("empleos.dat", ios::in | ios::binary);
		if (entrada.is_open()) {
			while (!entrada.eof())
			{
				entrada.read((char*)&e, sizeof(Empleo<int>));
				ListaE->agregarEmpleo(e);
			}
			entrada.close();
		}
		Console::Clear();
		cin.ignore(10000,'\n');
		cout << "Ingrese el nombre del puesto de trabajo que desea buscar: ";
		getline(cin, aux->empleo.puesto_trabajo);
		nodoE = ListaE->buscarNodo(aux);
		if (ListaE->hayElementos() == true)
		{
			while (finalizar == false)
			{
				e = nodoE->empleo;
				Console::Clear();
				cout << "------------------- " << e.puesto_trabajo << " ------------------- " << endl;
				cout << "Nombre de la empresa: " << e.empresa << endl;
				cout << "Ubicaci�n: " << e.ubicacion << endl;
				cout << "Funci�n laboral: " << e.funcion << endl;
				cout << "Descripci�n del puesto de trabajo: " << e.descripcion << endl;
				cout << "Sueldo: " << e.sueldo << endl;
				cout << "-------------------------------------- " << endl;
				do
				{
					cout << "Elija una opci�n" << endl;
					cout << "1. Siguiente" << endl;
					cout << "2. Anterior" << endl;
					cout << "3. ordenar de mayor a menor segun sueldo" << endl;
					cout << "4. ordenar de menor a mayor segun sueldo" << endl;
					cout << "5. Salir de la busqueda de empleo" << endl;
					cin >> op;
				} while (op > 5 || op < 1);
				switch (op)
				{
				case 1:
					nodoE = ListaE->NodoSiguiente(nodoE);
					break;
				case 2:
					nodoE = ListaE->NodoAnterior(nodoE);
					break;
				case 3:
					ListaE->Ordenamiento(2);
					break;
				case 4:
					ListaE->Ordenamiento(1);
					break;
				case 5:
					finalizar = true;
					delete ListaE;
					break;
				default:
					break;
				}

			}
		}
		else
		{
			cout << "Lista vacia" << endl;
			_getch();
		}
	}
	void buscarCurso() {
		ListaC = new ListaCurso();
		NodoCurso* aux = new NodoCurso();
		bool finalizar = false;
		int op;
		entrada.open("cursos.dat", ios::in | ios::binary);
		if (entrada.is_open()) {
			while (!entrada.eof())
			{
				entrada.read((char*)&c, sizeof(Curso<float>));
				ListaC->agregarCurso(c);
			}
			entrada.close();
		}
		Console::Clear();
		cin.ignore(10000,'\n');
		cout << "Ingrese el titulo del curso que desea buscar: ";
		getline(cin, aux->curso.titulo);
		nodoC = ListaC->buscarNodo(aux);
		if (ListaC->hayElementos() == true)
		{
			while (finalizar == false)
			{
				c = nodoC->curso;
				Console::Clear();
				cout << "------------------- " << c.titulo << " ------------------- " << endl;
				cout << "Tema: " << c.tema << endl;
				cout << "Profesor: " << c.profesor << endl;
				cout << "Fecha de publicacion: " << c.fecha_publicacion << endl;
				cout << "Costo del curso: " << c.costo << endl;
				cout << "-------------------------------------- " << endl;
				do
				{
					cout << "Elija una opci�n" << endl;
					cout << "1. Siguiente" << endl;
					cout << "2. Anterior" << endl;
					cout << "3. ordenar de mayor a menor segun costo" << endl;
					cout << "4. ordenar de menor a mayor segun costo" << endl;
					cout << "5. Salir de la busqueda de curso" << endl;
					cin >> op;
				} while (op > 5 || op < 1);
				switch (op)
				{
				case 1:
					nodoC = ListaC->NodoSiguiente(nodoC);
					break;
				case 2:
					nodoC = ListaC->NodoAnterior(nodoC);
					break;
				case 3:
					ListaC->Ordenamiento(2);
					break;
				case 4:
					ListaC->Ordenamiento(1);
					break;
				case 5:
					finalizar = true;
					delete ListaC;
					break;
				default:
					break;
				}

			}
		}
		else
		{
			cout << "Lista vacia" << endl;
			_getch();
		}
	}
	void buscarPersona() {
		Usuario auxU;
		int pos, op;
		bool finalizar = false;
		Console::Clear();
		cin.ignore(10000,'\n');
		cout << "Ingrese el nombre de la persona que desea buscar: ";
		getline(cin,auxU.nombre);
		pos = vectorU->buscarPersona(auxU);
		if (vectorU->getTamanio() != 0)
		{
			while (finalizar == false)
			{
				Console::Clear();
				auxU = vectorU->getUsuario(pos);
				cout << "-------------------" << auxU.nombre << "------------------ - " << endl;
				cout << "Edad: " << auxU.edad << endl;
				cout << "Profesi�n: " << auxU.profesion << endl;
				cout << "N�mero de contacto: " << auxU.telefono << endl;
				cout << "E-mail de contacto: " << auxU.correo << endl;
				cout << "-------------------------------------- " << endl;
				do
				{
					cout << "Elija una opci�n" << endl;
					cout << "1. Siguiente" << endl;
					cout << "2. Anterior" << endl;
					cout << "3. Agregar como amigo" << endl;
					cout << "4. Salir de la busqueda de persona" << endl;
					cin >> op;
				} while (op > 4 || op < 1);
				switch (op)
				{
				case 1:
					if (pos < vectorU->getTamanio() - 1) {
						pos += 1;
					}
					break;
				case 2:
					if (pos > 0)
					{
						pos -= 1;
					}
					break;
				case 3:
					break;
				case 4:
					finalizar = true;
					break;
				default:
					break;
				}
			}
		}
		else {
			cout << "Vector vac�o" << endl;
		}
	}
	void buscarProducto() {
		ListaP = new ListaProducto();
		NodoProducto* aux = new NodoProducto();
		bool finalizar = false;
		int op;
		entrada.open("producto.dat", ios::in | ios::binary);
		if (entrada.is_open()) {
			while (!entrada.eof())
			{
				entrada.read((char*)&p, sizeof(Producto<float>));
				ListaP->agregarProducto(p);
			}
			entrada.close();
		}
		Console::Clear();
		cin.ignore(10000,'\n');
		cout << "Ingrese el titulo del curso que desea buscar: ";
		getline(cin,aux->producto.nombre_producto);
		nodoP = ListaP->buscarNodo(aux);
		if (ListaP->hayElementos() == true)
		{
			while (finalizar == false)
			{
				p = nodoP->producto;
				Console::Clear();
				cout << "------------------- " << p.nombre_producto << " ------------------- " << endl;
				cout << "Nombre de la empresa: " << p.nombre_empresa << endl;
				cout << "Descripcion: " << p.descripcion << endl;
				cout << "Costo del producto: " << p.costo << endl;
				cout << "-------------------------------------- " << endl;
				do
				{
					cout << "Elija una opci�n" << endl;
					cout << "1. Siguiente" << endl;
					cout << "2. Anterior" << endl;
					cout << "3. ordenar de mayor a menor segun costo" << endl;
					cout << "4. ordenar de menor a mayor segun costo" << endl;
					cout << "5. Salir de la busqueda de producto" << endl;
					cin >> op;
				} while (op > 5 || op < 1);
				switch (op)
				{
				case 1:
					nodoP = ListaP->NodoSiguiente(nodoP);
					break;
				case 2:
					nodoP = ListaP->NodoAnterior(nodoP);
					break;
				case 3:
					ListaP->Ordenamiento(2);
					break;
				case 4:
					ListaP->Ordenamiento(1);
					break;
				case 5:
					finalizar = true;
					delete ListaP;
					break;
				default:
					break;
				}

			}
		}
		else
		{
			cout << "Lista vacia" << endl;
			_getch();
		}
	}
	void buscarEvento() {
		ListaEV = new ListaEvento();
		NodoEvento* aux = new NodoEvento();
		bool finalizar = false;
		int op;
		entrada.open("evento.dat", ios::in | ios::binary);
		if (entrada.is_open()) {
			while (!entrada.eof())
			{
				entrada.read((char*)&ev, sizeof(Evento));
				ListaEV->agregarEvento(ev);
			}
			entrada.close();
		}
		Console::Clear();
		cout << "Ingrese el nombre del evento que desea buscar: ";
		cin >> aux->evento.nombre_evento;
		nodoEV = ListaEV->buscarNodo(aux);
		if (ListaEV->hayElementos() == true)
		{
			while (finalizar == false)
			{
				ev = nodoEV->evento;
				Console::Clear();
				cout << "------------------- " << ev.nombre_evento << " ------------------- " << endl;
				cout << "Tema: " << ev.tema << endl;
				cout << "Fecha: " << ev.fecha << endl;
				cout << "Direccion: " << ev.direccion << endl;
				cout << "Descripcion: " << ev.descripcion << endl;
				cout << "-------------------------------------- " << endl;
				do
				{
					cout << "Elija una opci�n" << endl;
					cout << "1. Siguiente" << endl;
					cout << "2. Anterior" << endl;
					cout << "3. Salir de la busqueda de evento" << endl;
					cin >> op;
				} while (op > 3 || op < 1);
				switch (op)
				{
				case 1:
					nodoEV = ListaEV->NodoSiguiente(nodoEV);
					break;
				case 2:
					nodoEV = ListaEV->NodoAnterior(nodoEV);
					break;
				case 3:
					finalizar = true;
					delete ListaEV;
					break;
				default:
					break;
				}

			}
		}
		else
		{
			cout << "Lista vacia" << endl;
			_getch();
		}
	}


	Usuario getActivo() {
		return activo;
	}
};


