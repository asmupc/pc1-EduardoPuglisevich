#pragma once
#include "Evento.h"
struct NodoEvento
{
	Evento evento;
	NodoEvento* siguiente;
	NodoEvento* anterior;
};
class ListaEvento
{
private:
	NodoEvento* primero;
	NodoEvento* ultimo;
public:
	ListaEvento() {
		primero = nullptr;
		ultimo = nullptr;
	};
	~ListaEvento() {};

	void agregarEvento(Evento ev) {
		NodoEvento* nodoNuevo = new NodoEvento();
		nodoNuevo->evento = ev;
		if (primero == nullptr)
		{
			primero = nodoNuevo;
			primero->siguiente = nullptr;
			primero->anterior = nullptr;
			ultimo = primero;
		}
		else
		{
			ultimo->siguiente = nodoNuevo;
			nodoNuevo->siguiente = nullptr;
			nodoNuevo->anterior = ultimo;
			ultimo = nodoNuevo;
		}
	}
	NodoEvento* buscarNodo(NodoEvento* aux) {
		bool resultado = false;
		int n;
		Evento ev;
		NodoEvento* actual = new NodoEvento();
		actual = primero;
		if (actual != nullptr)
		{

			while (actual != nullptr && resultado != true)
			{
				if (actual->evento.nombre_evento == aux->evento.nombre_evento)
				{
					resultado = true;
					aux = actual;
				}
				actual = actual->siguiente;
			}
			if (resultado == false)
			{
				cout << "El evento " << aux->evento.nombre_evento << " no se ha encontrado" << endl;
				_getch();
				return primero;
			}
			else
			{
				return aux;
			}
		}
	}
	NodoEvento* NodoSiguiente(NodoEvento* aux) {
		if (aux->siguiente != nullptr)
		{
			return aux->siguiente;
		}
		else
		{
			return aux;
		}
	}
	NodoEvento* NodoAnterior(NodoEvento* aux) {
		if (aux->anterior != nullptr)
		{
			return aux->anterior;
		}
		else
		{
			return aux;
		}
	}
	bool hayElementos() {
		if (primero == nullptr)
		{
			return false;
		}
		else
		{
			return true;
		}

	}
};