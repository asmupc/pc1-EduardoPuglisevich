#pragma once
#include "Librerias.h"
template<typename T>
struct Producto
{
    string nombre_producto;
    string nombre_empresa;
    string descripcion;
    T costo;
};