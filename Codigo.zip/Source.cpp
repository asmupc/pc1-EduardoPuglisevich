#include "Controlador.h"

Controlador* controlador = new Controlador();

void Perfil() {
	int n;
	bool salir = false;
	do
	{
		Console::Clear();
		cout << "-------------------PERFIL-------------------" << endl;
		cout << "Nombre: " << controlador->getActivo().nombre << endl;
		cout << "Edad: " << controlador->getActivo().edad << endl;
		cout << "Profesi�n: " << controlador->getActivo().profesion << endl;
		cout << "N�mero de contacto: " << controlador->getActivo().telefono << endl;
		cout << "E-mail de contacto: " << controlador->getActivo().correo << endl;
		cout << "---------------------------------------------" << endl << endl;
		cout << "QUE DESEAS HACER " << controlador->getActivo().nombre << ": " << endl;
		cout << "-----------------FUNCIONES-------------------" << endl;
		cout << "1. Buscar empleo" << endl;
		cout << "2. Buscar personas" << endl;
		cout << "3. Buscar curso" << endl;
		cout << "4. Buscar producto" << endl;
		cout << "5. Buscar evento" << endl;
		cout << "6. Publicar empleo" << endl;
		cout << "7. Publicar curso" << endl;
		cout << "8. Publicar producto" << endl;
		cout << "9. Publicar evento" << endl;
		cout << "10. Ver lista de amigos" << endl;
		cout << "11. Cerrar sesi�n" << endl;
		cin >> n;
		switch (n)
		{
		case 1:
			controlador->buscarEmpleo();
			break;
		case 2:
			controlador->buscarPersona();
			break;
		case 3:
			controlador->buscarCurso();
			break;
		case 4:
			controlador->buscarProducto();
			break;
		case 5:
			controlador->buscarEvento();
			break;
		case 6:
			controlador->publicarEmpleo();
			break;
		case 7:
			controlador->publicarCurso();
			break;
		case 8:
			controlador->publicarProducto();
			break;
		case 9:
			controlador->publicarEvento();
			break;
		case 10:
			controlador->Implementar_Amigos();
			_getch();
			break;
		case 11:
			salir = true;
			break;
		default:
			cout << "La opci�n seleccionada no es v�lida" << endl;
		}
	} while (salir == false);

}
void MenuInicio() {
	int n;
	bool salir = false;
	do
	{
		Console::Clear();
		cout << "--------- BIENVENIDO ---------" << endl;
		cout << "Elija una opci�n" << endl;
		cout << "1. Iniciar sesi�n" << endl;
		cout << "2. Crear cuenta" << endl;
		cout << "3. Salir del programa" << endl;
		cin >> n;
		switch (n)
		{
		case 1:
			if (controlador->Login() == true)
			{
				Perfil();
			}
			break;
		case 2:
			controlador->signUp();
			break;
		case 3:
			salir = true;
			break;
		default:
			cout << "La opci�n seleccionada no es v�lida" << endl;
		}
	} while (salir == false);
}
void main() {
	locale::global(locale("spanish"));
	Console::Title = "BuscaEmpleo";
	MenuInicio();
}
