#pragma once
#include "Empleo.h"
template<typename T>
struct TreeNode
{
	T element;
	TreeNode<T>* left;
	TreeNode<T>* right;
	TreeNode<T>* mid;
};
template<typename T>
class TernaryTree
{
private:
	TreeNode<T>* root;
	function<void(T)> show;
	function<char(T)> data;
public:

	TernaryTree(function<void(T)> show, function<char(T)> data) : show(show), data(data) {
		root = nullptr;
	};
	~TernaryTree() {};
	//insertar
	void Insert(T e) {
		_Insert(root, e);
	}
	bool _Insert(TreeNode<T>*& node, T e) {
		if (node == nullptr)
		{
			node = new TreeNode<T>();
			node->element = e;

		}
		else if (data(e) == data(node->element)) _Insert(node->mid, e);
		else if (data(e) < data(node->element))  _Insert(node->left, e);
		else if (data(e) > data(node->element))  _Insert(node->right, e);
		return true;
	}
	//Print
	void print(TreeNode<T>* node) {
		if (node == nullptr) return;
		show(node->element);
		print(node->left);
		print(node->mid);
		print(node->right);
	}
	//busqueda
	TreeNode<T>* Search(TreeNode<T>* node, T d, function<string(T)> name) {
		if (node == nullptr) return nullptr;
		else
		{
			if (name(node->element) == name(d))
			{
				cout << "Dato Encontrado" << endl;
				return node;
			}
			else if (data(d) < data(node->element)) return Search(node->left, d,name);
			else if (data(d) > data(node->element)) return Search(node->right, d,name);
			else if (data(d) == data(node->element)) return Search(node->mid, d,name);
		}
	}
	//Eliminacion
	bool _eliminar(TreeNode<T>*& node, T d, function<string(T)> name) {
		if (node == nullptr) return false;
		else
		{
			if (name(node->element) == name(d))
			{
				if (node->left == nullptr && node->right == nullptr && node->mid == nullptr)
				{
					node = nullptr;
					delete node;
					return true;
				}
				else if (node->left == nullptr && node->mid == nullptr)
				{
					node = node->right;
					return true;
				}
				else if (node->right == nullptr && node->mid == nullptr)
				{
					node = node->left;
					return true;
				}
				else if (node->right == nullptr && node->left == nullptr)
				{
					node = node->mid;
					return true;
				}
				else if (node->mid == nullptr)
				{
					TreeNode<T>* nodeAux = node->right;
					while (nodeAux->left != nullptr)
					{
						nodeAux = nodeAux->left;
					}
					node->element = nodeAux->element;
					return _eliminar(node->right, nodeAux->element, name);
				}
				else {
					node->mid->left = node->left;
					node->mid->right = node->right;
					node = node->mid;
					return true;
				}
				cout << "Dato eliminado exitosamente" << endl;
				
			}
			else if (data(d) < data(node->element)) return _eliminar(node->left, d, name);
			else if (data(d) > data(node->element)) return _eliminar(node->right, d, name);
			else if (data(d) == data(node->element)) return _eliminar(node->mid, d, name);
		}
	}
	void eliminar(T d, function<string(T)> name){
		_eliminar(root, d, name);
	}
	void restart(TreeNode<T>* node, function<void(T)> rest) {
		if (node == nullptr) return;
		rest(node->element);
		restart(node->left,rest);
		restart(node->mid,rest);
		restart(node->right,rest);
	}
	//get altura
	int altura(TreeNode<T>* node) {
		if (node == nullptr) return 0;
		else
		{
			int ai, ad, am;
			ai = 1 + altura(node->left);
			ad = 1 + altura(node->right);
			am = 1 + altura(node->mid);
			if (ai > ad && ai > am) return ai;
			else if (ad > ai && ad > am) return ad;
			else return am;
		}
	}
	int cantidadElementos(TreeNode<T>* node) {
		if (node == nullptr)
		{
			return 0;
		}
		else
		{
			int ci, cd, cm;
			cm = cantidadElementos(node->mid);
			ci = cantidadElementos(node->left);
			cd = cantidadElementos(node->right);
			return 1 + ci + cd + cm;

		}
	}
	TreeNode<T>* getRoot() {
		return root;
	}
};
