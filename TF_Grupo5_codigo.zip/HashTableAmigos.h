#pragma once
#include "HashEntityAmigo.h"
template <typename T, typename T_key>
class HashTable
{
private:
	vector<list<HashEntity<T, T_key>>> VectorHash;
	int tamanio;
public:
	HashTable(int tam) {
		tamanio = tam;
		VectorHash.resize(tamanio);
	};
	~HashTable() {};
	void makeEmpty() {
		for (auto& sublista : VectorHash)
			sublista.clear();
	}

	unsigned int hashFunction(T_key key) {
		unsigned int val = 0;
		/*HASH FUNCTION PARA NOMBRES*/
		long long aux = 0;
		string palabra = key;
		int size = palabra.size() - 1;
		auto potencia = [](int i)-> long long {
			long long value = 27;
			if (i = 0) return 1;
			else {
				for (int k = 1; k < i; k++)
				{
					value = value * 27;
				}
				return value;
			}
		};
		for (int i = size; i > 0; i--)
		{
			int alpha = int(palabra.at(i)) - 65;
			aux += alpha * potencia(i);
		}
		val = aux % tamanio;
		return val;
	}

	bool insert(HashEntity<T, T_key> entity)
	{
		auto& whichList = VectorHash[hashFunction(entity.getKey())]; //Obtenemos la lista de elementos seg�n el hash obtenido
		whichList.push_back(entity); //Agregamos el nuevo elemento a la lista
		return true;
	}

	void print(function<void(T)> mostrar) {
		int pos = 0;
		cout << "DIRECTORIO DE AMIGOS" << endl << endl;
		for (auto& sublista : VectorHash) {
			cout << "Directorio " + to_string(pos) << " | ";
			for (auto& it : VectorHash[pos]) {
				mostrar(it.getValue());
			}
			cout << endl;
			pos++;
		}
	}

	void search(T_key value, function<void(T)> mostrar, function<T_key(T)> comparar) {
		bool confirm = false;
		auto& whichList = VectorHash[hashFunction(value)];
		for (auto& it : whichList) {
			if (comparar(it.getValue()) == value)
			{
				confirm = true;
				cout << "Valor encontrado: ";
				mostrar(it.getValue());
				cout << endl;
				break;
			}
		}
		if (confirm == false)
		{
			cout << "Valor no encontrado " << endl;
		}
	}

};