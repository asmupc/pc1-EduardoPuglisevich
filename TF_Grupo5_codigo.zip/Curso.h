#pragma once
#pragma once
#include "Librerias.h"
template<typename T>
struct Curso
{
    string tema;
    string titulo;
    string profesor;
    string fecha_publicacion;
    T costo;
};