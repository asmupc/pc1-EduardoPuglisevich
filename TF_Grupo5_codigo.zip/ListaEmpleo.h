#pragma once
#include "Empleo.h"
#include "Lista.h"
class ListaEmpleo:public Lista<Empleo<int>>
{
private:
public:
	ListaEmpleo() : Lista() {
	};
	~ListaEmpleo() {};
	template <typename T>
	Nodo<T>* buscarNodo(Nodo<T>* aux) {
		bool resultado = false;
		int n;
		Nodo<T>* actual = new Nodo<T>();
		actual = primero;
		if (actual != nullptr)
		{
			while (actual != nullptr && resultado != true)
			{
				if (actual->dato.puesto_trabajo == aux->dato.puesto_trabajo)
				{
					resultado = true;
					aux = actual;
				}
				actual = actual->siguiente;
			}
			if (resultado == false)
			{
				cout << "El trabajo " << aux->dato.puesto_trabajo << " no se ha encontrado" << endl;
				_getch();
				return primero;
			}
			else
			{
				return aux;
			}
		}
	}
	//ORDENAMIENTO RECURSIVO
	void Quicksort(vector<Empleo<int>>& v, int inicio, int fin, int n) {
		if (inicio < fin) {
			auto f1 = [&]() { 
			Empleo<int> aux;
			int pivote = v[inicio].sueldo;
			int i = inicio + 1;
			for (int j = i; j <= fin; j++) {
				if (n == 1)
				{
					if (v[j].sueldo < pivote) { aux = v[i]; v[i] = v[j]; v[j] = aux; i++; }
				}
				else if (n == 2)
				{
					if (v[j].sueldo > pivote) { aux = v[i]; v[i] = v[j]; v[j] = aux; i++; }
				}

			}
			aux = v[inicio];
			v[inicio] = v[i - 1];
			v[i - 1] = aux;
			return i - 1;
			};
			int pivote = f1();
			Quicksort(v, inicio, pivote - 1, n);
			Quicksort(v, pivote + 1, fin, n);
		}
	}
	Nodo<Empleo<int>>* Ordenamiento(int n) {
		vector<Empleo<int>>ve;
		int i = 0;
		Nodo<Empleo<int>>* actual = new Nodo<Empleo<int>>();
		actual = primero;
		while (actual != nullptr)
		{
			ve.push_back(actual->dato);
			actual = actual->siguiente;
		}
		actual = primero;
		switch (n)
		{
		case 1:
			Quicksort(ve, 0, ve.size() - 1, n);
			while (actual != nullptr)
			{
				actual->dato = ve[i];
				actual = actual->siguiente;
				i++;
			}
			break;
		case 2:
			Quicksort(ve, 0, ve.size() - 1, n);
			while (actual != nullptr)
			{
				actual->dato = ve[i];
				actual = actual->siguiente;
				i++;
			}
			break;
		default:
			break;
		}
		return primero;
	}

};