#pragma once
#include<iostream>
#include<iomanip>
#include<conio.h>
#include<math.h>
#include<time.h>
#include <vector>
#include <fstream>
#include <list>
#include <functional>
#include <sstream>
#include <string.h>
#include <string>
using namespace std;
using namespace System;

const int width = 100;
const int height = 25;