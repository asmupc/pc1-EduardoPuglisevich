#pragma once
#include "Practica.h"
//COLA DE PRIORIDAD MAXIMA
template <typename T>
class ColaDePrioridad
{
private:
	vector<T> v;
public:
	ColaDePrioridad() {
	};
	~ColaDePrioridad() {};

	void buildMaxHeap(function<int(T)> valor) {
		for (int i = v.size() / 2 - 1; i >= 0; --i) {
			MAX_HEAPIFY(v.size(), i,valor);
		}
	}
	int parent(int i) {
		return (i - 1) / 2;
	}
	int left(int i) {
		return i * 2 + 1;
	}
	int right(int i) {
		return i * 2 + 2;
	}
	
	void Ordenamiento(int n, function<int(T)> valor) {
		T aux;
		int tamanio = v.size();
		switch (n)
		{
		case 1:	
			for (int i = v.size() / 2 - 1; i >= 0; --i) {
				MIN_HEAPIFY(v.size(), i, valor);
			}
			//HEAPSORT DESCENDENTE
			for (int i = v.size() - 1; i > 0; --i)
			{
				aux = v[0];
				v[0] = v[i];
				v[i] = aux;
				MIN_HEAPIFY(--tamanio, 0, valor);
			}
			break;
		case 2:
			for (int i = v.size() / 2 - 1; i >= 0; --i) {
				MAX_HEAPIFY(v.size(), i, valor);
			}
			//HEAPSORT ASCENDENTE
			for (int i = v.size() - 1; i > 0; --i)
			{
				aux = v[0];
				v[0] = v[i];
				v[i] = aux;
				MAX_HEAPIFY(--tamanio, 0, valor);
			}
			break;
		default:
			break;
		}
	}
	void MAX_HEAPIFY(int tamanio, int i, function<int(T)> valor) {
		int largest;
		T aux;
		int l = left(i);
		int r = right(i);
		if (l <= tamanio - 1 && valor(v[l]) > valor(v[i])) largest = l;
		else largest = i;
		if (r <= tamanio - 1 && valor(v[r]) > valor(v[largest])) largest = r;
		if (largest != i)
		{
			aux = v[i];
			v[i] = v[largest];
			v[largest] = aux;
			MAX_HEAPIFY(tamanio, largest,valor);
		}
	}
	void MIN_HEAPIFY(int tamanio, int i,function<int(T)> valor) {
		int smallest;
		T aux;
		int l = left(i);
		int r = right(i);
		if (l <= tamanio - 1 && valor(v[l]) < valor(v[i])) smallest = l;
		else smallest = i;
		if (r <= tamanio - 1 && valor(v[r]) < valor(v[smallest])) smallest = r;
		if (smallest != i)
		{
			aux = v[i];
			v[i] = v[smallest];
			v[smallest] = aux;
			MIN_HEAPIFY(tamanio, smallest,valor);
		}
	}

	void insert(T d, function<int(T)> valor) {
		T aux;
		v.push_back(d);
		int i = v.size() - 1;
		while (i > 0 && valor(v[parent(i)]) < valor(v[i]))
		{
			aux = v[i];
			v[i] = v[parent(i)];
			v[parent(i)] = aux;
			i = parent(i);
		}
	}
	int Busqueda(T d, function<string(T)> nombre) {
		bool resultado = false;
		for (int i = 0; i < v.size(); i++)
		{
			if (nombre(v[i]) == nombre(d))
			{
				resultado = true;
				return i;
			}
		}
		if (resultado == false)
		{
			cout << "La practica laboral " << nombre(d) << " no se ha encontrado" << endl;
			_getch();
			return 0;
		}
		
	}
	/*T extract_max()
	{
		if (v.size() <= 0)
		{
			cerr << "heap overflow" << endl;
		}
		T max = v[0];
		int tamanio = v.size();
		v[0] = v[v.size() - 1];
		v.erase(begin(v) + v.size() - 1);
		MAX_HEAPIFY(v.size(), 0);
		return max;
	}*/

	int getTamanio() {
		return v.size();
	}
	T getDato(int pos) {
		return v[pos];
	}
};
