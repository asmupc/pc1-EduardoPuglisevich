#pragma once
#include "Librerias.h"
template<typename T>
struct Nodo
{
	T dato;
	Nodo <T>* siguiente;
	Nodo <T>* anterior;
};
template<typename T>
class Lista
{
protected:
	Nodo<T>* primero;
	Nodo<T>* ultimo;
public:
	Lista() {
		primero = nullptr;
		ultimo = nullptr;
	};
	~Lista() {};
	void agregarDato(T c) {
		Nodo<T>* nodoNuevo = new Nodo<T>();
		nodoNuevo->dato = c;
		if (primero == nullptr)
		{
			primero = nodoNuevo;
			primero->siguiente = nullptr;
			primero->anterior = nullptr;
			ultimo = primero;
		}
		else
		{
			ultimo->siguiente = nodoNuevo;
			nodoNuevo->siguiente = nullptr;
			nodoNuevo->anterior = ultimo;
			ultimo = nodoNuevo;
		}
	}
	Nodo<T>* NodoSiguiente(Nodo<T>* aux) {
		if (aux->siguiente != nullptr)
		{
			return aux->siguiente;
		}
		else
		{
			return aux;
		}
	}
	Nodo<T>* NodoAnterior(Nodo<T>* aux) {
		if (aux->anterior != nullptr)
		{
			return aux->anterior;
		}
		else
		{
			return aux;
		}
	}
	bool hayElementos() {
		if (primero == nullptr)
		{
			return false;
		}
		else
		{
			return true;
		}

	}
	int getTamanio() {
		int n = 0;
		Nodo<T>* actual = new Nodo<T>();
		actual = primero;
		if (primero != nullptr) {

			while (actual != nullptr) {
				n++;
				actual = actual->siguiente;
			}
		}
		else {
			cout << "La lista esta vacia";
		}
		return n;
	}
	Nodo<T>* getPrimero(Nodo<T>* aux) {
		return primero;
	}
};