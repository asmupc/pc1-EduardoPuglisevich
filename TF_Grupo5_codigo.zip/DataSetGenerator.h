#pragma once
#include "VectorUsuario.h"
class DataSet
{
private:
	int cant,laps;
	ofstream salida;
    ifstream entrada;
public:
	DataSet(int n) {
		cant = n;
        laps = cant / 1400;
	};
	~DataSet() {};

	void Generate(VectorUsuario*& v) {
        int cont = 0;
        string linea;
        for (int i = 0; i < laps+1; i++)
        {
            entrada.open("DataSet.csv", ios::in);
            getline(entrada, linea);
            while (getline(entrada, linea) && cont < cant) {
                stringstream stream(linea);
                string aux;
                Usuario user;
                getline(stream, aux, ',');
                user.nombre = aux;
                getline(stream, aux, ',');
                user.profesion = aux;
                user.edad = rand() % (46 - 18) + 18;
                user.telefono = "9";
                for (int i = 0; i < 8; i++)
                {
                    user.telefono += to_string(rand() % 10);
                }
                user.correo = user.nombre + "@gmail.com";
                for (int i = 0; i < 8; i++)
                {
                    user.contrasena += char(rand() % (91 - 65) + 65);
                }
                cont++;
                v->agregarUsuario(user);
            }
            entrada.close();
        }
	}
    

};
