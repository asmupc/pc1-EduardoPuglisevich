#pragma once
#include "Curso.h"
#include "Lista.h"

class ListaCurso : public Lista<Curso<float>>
{
private:
public:
	ListaCurso() : Lista() {
	};
	~ListaCurso() {};
	template<typename T>
	void agregarDatoCircular(T c) {
		Nodo<T>* nodoNuevo = new Nodo<T>();
		nodoNuevo->dato = c;
		if (primero == nullptr) {
			primero = nodoNuevo;
			ultimo = nodoNuevo;
			primero->siguiente = primero;
			primero->anterior = ultimo;

		}
		else {

			ultimo->siguiente = nodoNuevo;
			nodoNuevo->siguiente = primero;
			nodoNuevo->anterior = ultimo;
			ultimo = nodoNuevo;
			primero->anterior = ultimo;

		}
	}
	template<typename T>
	Nodo<T>* buscarNodo(Nodo<T>* aux) {
		bool resultado = false;
		int n;
		Nodo<T>* actual = new Nodo<T>();
		actual = primero;
		if (actual != nullptr)
		{
			while (actual != ultimo && resultado != true)
			{
				if (actual->dato.titulo == aux->dato.titulo)
				{
					resultado = true;
					aux = actual;
				}
				actual = actual->siguiente;
			}
			if (actual == ultimo)
			{
				if (actual->dato.titulo == aux->dato.titulo)
				{
					resultado = true;
					aux = actual;
				}
			}
			if (resultado == false)
			{
				cout << "El curso " << aux->dato.titulo << " no se ha encontrado" << endl;
				_getch();
				return primero;
			}
			else
			{
				return aux;
			}
		}
	}
	//ORDENAMIENTO RECURSIVO
	Nodo<Curso<float>>* Ordenamiento(function<bool(Curso<float>, Curso<float>,int tipo)> compare,int n) {
		vector<Curso<float>>vc;
		int i = 0;
		Nodo<Curso<float>>* actual = new Nodo<Curso<float>>();
		actual = primero;
		while (actual != ultimo)
		{
			vc.push_back(actual->dato);
			actual = actual->siguiente;
		}
		vc.push_back(actual->dato);
		actual = primero;
		switch (n)
		{
		case 1:
			mergeSort(vc, compare,n);
			while (actual != ultimo)
			{
				actual->dato = vc[i];
				actual = actual->siguiente;
				i++;
			}
			actual->dato = vc[i];
			break;
		case 2:
			mergeSort(vc, compare,n);
			while (actual != ultimo)
			{

				actual->dato = vc[i];
				actual = actual->siguiente;
				i++;
			}
			actual->dato = vc[i];
			break;
		default:
			break;
		}
		return primero;
	}
	void merge(vector<Curso<float>> v1, vector<Curso<float>> v2, vector<Curso<float>>& v, function<bool(Curso<float>, Curso<float>,int tipo)>compare,int n) {
		int j, i, k;
		i = j = k = 0;
		while (i < v.size() / 2 && j < v.size() - v.size() / 2)
		{
			if (compare(v1[i], v2[j],n))
			{
				v[k] = v1[i];
				i++;
				k++;
			}
			else
			{
				v[k] = v2[j];
				j++;
				k++;
			}
		}
		while (i < v.size() / 2)
		{
			v[k] = v1[i];
			i++;
			k++;
		}
		while (j < v.size() - v.size() / 2)
		{
			v[k] = v2[j];
			j++;
			k++;
		}
	}
	void mergeSort(vector<Curso<float>>& v, function<bool(Curso<float>, Curso<float>,int tipo)>compare,int n) {
		vector<Curso<float>>v1;
		vector<Curso<float>>v2;
		if (v.size() > 1)
		{
			for (int i = 0; i < v.size() / 2; i++)
			{
				v1.push_back(v[i]);
			}
			for (int i = v.size() / 2; i < v.size(); i++)
			{
				v2.push_back(v[i]);
			}
			mergeSort(v1, compare,n);
			mergeSort(v2, compare,n);
			merge(v1, v2, v, compare,n);
		}
	}

};