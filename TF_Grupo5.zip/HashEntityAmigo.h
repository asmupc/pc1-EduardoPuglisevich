#pragma once
#pragma once
#include "Librerias.h"
template <typename T, typename T_key>
class HashEntity
{
private:
	T value;
	T_key key;
public:

	HashEntity(T value, T_key key) {
		this->value = value;
		this->key = key;
	};
	~HashEntity() {
	};

	T getValue() {
		return value;
	}

	T_key getKey() {
		return key;
	}
};
