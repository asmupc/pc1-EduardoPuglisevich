#include "Controlador.h"

Controlador* controlador = new Controlador();


void Perfil() {
	int n;
	bool salir = false;
	do
	{
		Console::Clear();
		cout << "-------------------PERFIL-------------------" << endl;
		cout << "Nombre: " << controlador->getActivo().nombre << endl;
		cout << "Edad: " << controlador->getActivo().edad << endl;
		cout << "Profesi�n: " << controlador->getActivo().profesion << endl;
		cout << "N�mero de contacto: " << controlador->getActivo().telefono << endl;
		cout << "E-mail de contacto: " << controlador->getActivo().correo << endl;
		cout << "---------------------------------------------" << endl << endl;
		cout << "QUE DESEAS HACER " << controlador->getActivo().nombre << ": " << endl;
		cout << "-----------------FUNCIONES-------------------" << endl;
		cout << "1. Buscar empleo" << endl;
		cout << "2. Buscar practicas" << endl;
		cout << "3. Buscar personas" << endl;
		cout << "4. Buscar curso" << endl;
		cout << "5. Buscar producto" << endl;
		cout << "6. Buscar evento" << endl;
		cout << "7. Publicar empleo" << endl;
		cout << "8. Publicar practica" << endl;
		cout << "9. Publicar curso" << endl;
		cout << "10. Publicar producto" << endl;
		cout << "11. Publicar evento" << endl;
		cout << "12. Ver lista de amigos" << endl;
		cout << "13. Cerrar sesi�n" << endl;
		cin >> n;
		switch (n)
		{
		case 1:
			controlador->buscarEmpleo();
			break;
		case 2:
			controlador->buscarPractica();
			break;
		case 3:
			controlador->buscarPersona();
			break;
		case 4:
			controlador->buscarCurso();
			break;
		case 5:
			controlador->buscarProducto();
			break;
		case 6:
			controlador->buscarEvento();
			break;
		case 7:
			controlador->publicarEmpleo();
			break;
		case 8:
			controlador->publicarPractica();
			break;
		case 9:
			controlador->publicarCurso();
			break;
		case 10:
			controlador->publicarProducto();
			break;
		case 11:
			controlador->publicarEvento();
			break;
		case 12:
			controlador->MostrarAmigos();
			_getch();
			break;
		case 13:
			salir = true;
			controlador->reset();
			break;
		default:
			cout << "La opci�n seleccionada no es v�lida" << endl;
		}
	} while (salir == false);

}

void MenuInicio() {
	int n;
	bool salir = false;
	do
	{
		cout << "--------------. BIENVENIDO -------------" << endl;
		cout << "Elija una opci�n" << endl;
		cout << "1. Iniciar sesi�n" << endl;
		cout << "2. Crear cuenta" << endl;
		cout << "3. Salir del programa" << endl;
		cout << "Seleccione una opcion:";
		cin >> n;
		Console::Clear();
		switch (n)
		{
		case 1:
			if (controlador->Login() == true)
			{
				Perfil();
			}
			break;
		case 2:
			controlador->signUp();
			break;
		case 3:
			salir = true;
			break;
		default:
			cout << "La opci�n seleccionada no es v�lida" << endl;
		}
	} while (salir == false);
}
void main() {
	locale::global(locale("spanish"));
	Console::Title = "BuscaEmpleo";
	Console::SetWindowSize(width,height);
	MenuInicio();
}
