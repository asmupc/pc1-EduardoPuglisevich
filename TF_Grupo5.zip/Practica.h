#pragma once
#include "Librerias.h"
template<typename T>
struct Practica
{
    string empresa_practica;
    string puesto_practica;
    string ubicacion;
    string descripcion;
    int urgencia;
    string carrera;
    int ciclo;
    T pago;
};