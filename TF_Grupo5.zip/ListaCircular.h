#pragma once
#include "Librerias.h"
template<typename T>
struct NodoCircular
{
	T dato;
	NodoCircular <T>* siguiente;
};
template<typename T>
class ListaCircular
{
protected:
	NodoCircular<T>* cursor;
	NodoCircular<T>* ultimo;
public:
	ListaCircular() {
		cursor = nullptr;
		ultimo = nullptr;
	};
	~ListaCircular() {};
	void agregarDato(T c) {
		NodoCircular<T>* nodoNuevo = new NodoCircular<T>();
		nodoNuevo->dato = c;
		if (cursor == nullptr)
		{
			cursor = nodoNuevo;
			cursor->siguiente = nullptr;
			ultimo = cursor;
		}
		else
		{
			ultimo->siguiente = nodoNuevo;
			nodoNuevo->siguiente = cursor;
			ultimo = nodoNuevo;
		}
	}
	NodoCircular<T>* NodoSiguiente(NodoCircular<T>* aux) {
		if (aux->siguiente != nullptr)
		{
			return aux->siguiente;
		}
		else
		{
			return aux;
		}
	}
	bool hayElementos() {
		if (cursor == nullptr)
		{
			return false;
		}
		else
		{
			return true;
		}

	}
	int getTamanio() {
		int n = 0;
		NodoCircular<T>* actual = new NodoCircular<T>();
		actual = cursor;
		if (cursor != nullptr) {

			while (actual != nullptr) {
				n++;
				actual = actual->siguiente;
			}
		}
		else {
			cout << "La lista esta vacia";
		}
		return n;
	}
	NodoCircular<T>* getPrimero() {
		return cursor;
	}
};