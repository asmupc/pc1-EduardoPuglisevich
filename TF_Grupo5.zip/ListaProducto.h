#pragma once
#include "Producto.h"
#include "ListaCircular.h"
class ListaProducto : public ListaCircular<Producto<float>>
{
private:
public:
	ListaProducto() :ListaCircular() {
	};
	~ListaProducto() {};
	template<typename T>
	NodoCircular<T>* buscarNodo(NodoCircular<T>* aux) {
		bool resultado = false;
		int n;
		NodoCircular<T>* actual = new NodoCircular<T>();
		actual = cursor;
		if (actual != nullptr)
		{
			while (actual != ultimo && resultado != true)
			{
				if (actual->dato.nombre_producto == aux->dato.nombre_producto)
				{
					resultado = true;
					aux = actual;
				}
				actual = actual->siguiente;
			}
			if (actual == ultimo)
			{
				if (actual->dato.nombre_producto == aux->dato.nombre_producto)
				{
					resultado = true;
					aux = actual;
				}
			}
			if (resultado == false)
			{
				cout << "El producto " << aux->dato.nombre_producto << " no se ha encontrado" << endl;
				_getch();
				return cursor;
			}
			else
			{
				return aux;
			}
		}
	}

	//ORDENAMIENTO RECURSIVO
	void Quicksort(vector<Producto<float>>& v, int inicio, int fin, int n) {
		if (inicio < fin) {
			auto f1 = [&]() {
				Producto<float> aux;
				int pivote = v[inicio].costo;
				int i = inicio + 1;
				for (int j = i; j <= fin; j++) {
					if (n == 1)
					{
						if (v[j].costo < pivote) { aux = v[i]; v[i] = v[j]; v[j] = aux; i++; }
					}
					else if (n == 2)
					{
						if (v[j].costo > pivote) { aux = v[i]; v[i] = v[j]; v[j] = aux; i++; }
					}

				}
				aux = v[inicio];
				v[inicio] = v[i - 1];
				v[i - 1] = aux;
				return i - 1;
			};
			int pivote = f1();
			Quicksort(v, inicio, pivote - 1, n);
			Quicksort(v, pivote + 1, fin, n);
		}
	}
	NodoCircular<Producto<float>>* Ordenamiento(int n) {
		NodoCircular<Producto<float>>* temp = new NodoCircular<Producto<float>>();
		vector<Producto<float>>vp;
		int i = 0;
		NodoCircular<Producto<float>>* actual = new NodoCircular<Producto<float>>();
		actual = cursor;
		while (actual != ultimo)
		{
			vp.push_back(actual->dato);
			actual = actual->siguiente;
		}
		vp.push_back(actual->dato);
		actual = cursor;
		switch (n)
		{
		case 1:
			Quicksort(vp, 0, vp.size() - 1, n);
			while (actual != ultimo)
			{
				if (i == 0) temp->dato = vp[i];
				actual->dato = vp[i];
				actual = actual->siguiente;
				i++;
			}
			actual->dato = vp[i];
			break;
		case 2:
			Quicksort(vp, 0, vp.size() - 1, n);
			while (actual != ultimo)
			{
				actual->dato = vp[i];
				actual = actual->siguiente;
				i++;
			}
			actual->dato = vp[i];
			break;
		default:
			break;
		}
		return cursor;
	}

};