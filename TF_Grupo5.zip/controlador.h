#pragma once
#include "VectorUsuario.h"
#include "ListaEmpleo.h"
#include "ListaCurso.h"
#include "ListaProducto.h"
#include "ColaEvento.h"
#include "HashTableAmigos.h"
#include "DataSetGenerator.h"
#include "ColaDePrioridad.h"

class Controlador
{
private:
	VectorUsuario* vectorU;
	ListaEmpleo* ListaE;
	ListaCurso* ListaC;
	ListaProducto* ListaP;
	ColaEvento* ColaEV;
	HashTable<Usuario, string>* ht;
	Usuario u;
	Usuario activo;
	Empleo<int> e;
	Curso<float> c;
	Producto<float> p;
	Practica<float> pr;
	Evento ev;
	HashEntity<Usuario, string>* he;
	Nodo<Empleo<int>>* nodoE;
	Nodo<Curso<float>>* nodoC;
	NodoCircular<Producto<float>>* nodoP;
	Nodo<Evento>* nodoEV;
	ofstream salida;
	ifstream entrada;
	string ArchNameAmigos;
	DataSet* generador;
public:
	Controlador() {
		ArchNameAmigos = "";
		vectorU = new VectorUsuario();
		vectorU->limpiar();
		generador = new DataSet(10);
		
	};
	~Controlador() {};
	void signUp() {
		salida.open("registroManual.dat", ios::out | ios::app | ios::binary);
		if (salida.is_open()) {
			cout << " REGISTRO DE CUENTA " << endl;
			cin.ignore(10000,'\n');
			cout << " Ingrese su nombre: ";
			getline(cin, u.nombre);
			cout << " Ingrese su edad: ";
			cin >> u.edad;
			cin.ignore(10000,'\n');
			cout << " Ingrese su profesi�n: ";
			getline(cin, u.profesion);
			cout << " Ingrese su telefono: ";
			getline(cin, u.telefono);
			cout << " Ingrese su correo: ";
			getline(cin, u.correo);
			cout << " Ingrese su contrase�a: ";
			getline(cin, u.contrasena);
			salida.write((const char*)&u, sizeof(Usuario));
			salida.close();
		}
		else
		{
			cout << "ERROR" << endl;
		}
	}
	bool Login() {
		bool validacion;
		Usuario auxU;
		generador->Generate(vectorU);
		entrada.open("registroManual.dat", ios::in | ios::binary);
		while (!entrada.eof())
		{
			entrada.read((char*)&u, sizeof(Usuario));
			if (!entrada.eof())
			{
				vectorU->agregarUsuario(u);
			}
		}
		entrada.close();
		cout << " INICIO DE SESION " << endl;
		cin.ignore(10000, '\n');
		cout << "Ingrese su correo: ";
		getline(cin, auxU.correo);
		cout << "Ingrese su contrase�a: ";
		getline(cin, auxU.contrasena);
		validacion = vectorU->comprobarAutenticidad(auxU);
		if (validacion == true)
		{
			activo = vectorU->getUsuarioActivo(auxU);
			ArchNameAmigos += activo.nombre + "Friends.txt";
			salida.open(ArchNameAmigos, ios::out | ios::app);
			if (salida.is_open())
			{
				salida.close();
			}
		}
		else
		{
			cout << "Correo electronico o contrase�a incorrecta" << endl;
			vectorU->limpiar();
		}
		cout << "Presione cualquier tecla para continuar" << endl;
		_getch();
		return validacion;
	}

	void publicarCurso() {
		Console::Clear();
		salida.open("cursos.dat", ios::out | ios::app | ios::binary);
		if (salida.is_open()) {
			cout << "--------- PUBLICACI�N DE CURSO ---------" << endl;
			cin.ignore(10000,'\n');
			cout << " Ingrese el tema del curso: ";
			getline(cin, c.tema);
			cout << " Ingrese el titulo del curso: ";
			getline(cin, c.titulo);
			cout << " Ingrese el nombre del profesor: ";
			getline(cin, c.profesor);
			cout << " Ingrese la fecha de publicacion del curso: ";
			getline(cin, c.fecha_publicacion);
			cout << " Ingrese el costo del curso: ";
			cin >> c.costo;
			cin.ignore(10000, '\n');
			salida.write((const char*)&c, sizeof(Curso<float>));
			salida.close();
		}
		else
		{
			cout << "ERROR" << endl;
		}
	}
	void publicarEmpleo() {
		Console::Clear();
		salida.open("empleos.dat", ios::out | ios::app | ios::binary);
		if (salida.is_open()) {
			cout << "--------- PUBLICACI�N DE EMPLEO ---------" << endl;
			cin.ignore(10000,'\n');
			cout << " Ingrese el puesto de trabajo: ";
			getline(cin, e.puesto_trabajo);
			cout << " Ingrese el nombre de la empresa: ";
			getline(cin, e.empresa);
			cout << " Ingrese la ubicacion donde se realizara el trabajo: ";
			getline(cin, e.ubicacion);
			cout << " Ingrese una peque�a descripci�n del puesto de trabajo: ";
			getline(cin, e.descripcion);
			cout << " Ingrese la funcion laboral que se debe realizar: ";
			getline(cin, e.funcion);
			cout << " Ingrese el sueldo que se ganara en su puesto de trabajo:";
			cin >> e.sueldo;
			cin.ignore(10000, '\n');
			salida.write((const char*)&e, sizeof(Empleo<int>));
			salida.close();
		}
		else
		{
			cout << "ERROR" << endl;
		}
	}
	void publicarPractica() {
		Console::Clear();
		salida.open("practicas.dat", ios::out | ios::app | ios::binary);
		if (salida.is_open()) {
			cout << "--------- PUBLICACI�N DE EMPLEO ---------" << endl;
			cin.ignore(10000, '\n');
			cout << " Ingrese el puesto de practica laborar: ";
			getline(cin, pr.puesto_practica);
			cout << " Ingrese el nombre de la empresa: ";
			getline(cin, pr.empresa_practica);
			cout << " Ingrese la ubicacion donde se realizara la practica laboral: ";
			getline(cin, pr.ubicacion);
			cout << " Ingrese una peque�a descripci�n del puesto de trabajo: ";
			getline(cin, pr.descripcion);
			cout << "Ingrese la carrera de los practicantes que esta buscando: ";
			getline(cin, pr.carrera);
			cout << "Ingrese el ciclo minimo de los practicantes que esta buscando: ";
			cin >> pr.ciclo;
			cout << " Ingrese la remuneraci�n de la practica laboral:";
			cin >> pr.pago;
			cout << " Ingrese la urgencia del puesto:";
			cin >> pr.urgencia;
			cin.ignore(10000, '\n');
			salida.write((const char*)&pr, sizeof(Practica<float>));
			salida.close();
		}
		else
		{
			cout << "ERROR" << endl;
		}
	}
	void publicarProducto() {
		Console::Clear();
		salida.open("producto.dat", ios::out | ios::app | ios::binary);
		if (salida.is_open()) {
			cout << "--------- PUBLICACI�N DE PRODUCTO ---------" << endl;
			cin.ignore(10000,'\n');
			cout << " Ingrese el nombre del producto: ";
			getline(cin, p.nombre_producto);
			cout << " Ingrese el nombre de la empresa: ";
			getline(cin, p.nombre_empresa);
			cout << " Ingrese una breve descripcion: ";
			getline(cin,p.descripcion);
			cout << " Ingrese el costo del producto: ";
			cin >> p.costo;
			cin.ignore(10000, '\n');
			salida.write((const char*)&p, sizeof(Producto<float>));
			salida.close();
		}
		else
		{
			cout << "ERROR" << endl;
		}
	}
	void publicarEvento() {
		Console::Clear();
		salida.open("evento.dat", ios::out | ios::app | ios::binary);
		if (salida.is_open()) {
			cout << "--------- PUBLICACI�N DE EVENTO ---------" << endl;
			cout << " Ingrese el nombre del evento: ";
			cin >> ev.nombre_evento;
			cout << " Ingrese el tema del evento: ";
			cin >> ev.tema;
			cout << " Ingrese la fecha del evento: ";
			cin >> ev.fecha;
			cout << " Ingrese la direccion del evento: ";
			cin >> ev.direccion;
			cout << " Ingrese una breve descripcion del evento: ";
			cin >> ev.descripcion;
			salida.write((const char*)&ev, sizeof(Evento));
			salida.close();
		}
		else
		{
			cout << "ERROR" << endl;
		}
	}

	void buscarEmpleo() {
		ListaE = new ListaEmpleo();
		Nodo<Empleo<int>>* aux = new Nodo<Empleo<int>>();
		bool finalizar = false;
		int op;
		entrada.open("empleos.dat", ios::in | ios::binary);
		if (entrada.is_open()) {
			while (!entrada.eof())
			{
				entrada.read((char*)&e, sizeof(Empleo<int>));
				if (!entrada.eof())
				{
					ListaE->agregarDato(e);
				}
			}
			entrada.close();
		}
		Console::Clear();
		cin.ignore(10000,'\n');
		cout << "Ingrese el nombre del puesto de trabajo que desea buscar: ";
		getline(cin, aux->dato.puesto_trabajo);
		nodoE = ListaE->buscarNodo(aux);
		if (ListaE->hayElementos() == true)
		{
			while (finalizar == false)
			{
				e = nodoE->dato;
				Console::Clear();
				cout << "------------------- " << e.puesto_trabajo << " ------------------- " << endl;
				cout << "Nombre de la empresa: " << e.empresa << endl;
				cout << "Ubicaci�n: " << e.ubicacion << endl;
				cout << "Funci�n laboral: " << e.funcion << endl;
				cout << "Descripci�n del puesto de trabajo: " << e.descripcion << endl;
				cout << "Sueldo: " << e.sueldo << endl;
				cout << "-------------------------------------- " << endl;
				do
				{
					cout << "Elija una opci�n" << endl;
					cout << "1. Siguiente" << endl;
					cout << "2. Anterior" << endl;
					cout << "3. ordenar de mayor a menor segun sueldo" << endl;
					cout << "4. ordenar de menor a mayor segun sueldo" << endl;
					cout << "5. Salir de la busqueda de empleo" << endl;
					cin >> op;
				} while (op > 5 || op < 1);
				switch (op)
				{
				case 1:
					nodoE = ListaE->NodoSiguiente(nodoE);
					break;
				case 2:
					nodoE = ListaE->NodoAnterior(nodoE);
					break;
				case 3:
					nodoE = ListaE->Ordenamiento(2);
					break;
				case 4:
					nodoE = ListaE->Ordenamiento(1);
					break;
				case 5:
					finalizar = true;
					delete ListaE;
					break;
				default:
					break;
				}

			}
		}
		else
		{
			cout << "Lista vacia" << endl;
			_getch();
		}
	}
	void buscarPractica() {
		Practica<float> auxPr;
		auto valor = [](Practica<float> x)->int {return x.pago; };
		auto urgencia = [](Practica<float> x)->int {return x.urgencia; };
		auto name = [](Practica<float> x)->string {return x.puesto_practica; };
		ColaDePrioridad<Practica<float>>* maxPract = new ColaDePrioridad<Practica<float>>;
		bool finalizar = false;
		int op,pos;
		entrada.open("practicas.dat", ios::in | ios::binary);
		if (entrada.is_open()) {
			while (!entrada.eof())
			{
				entrada.read((char*)&pr, sizeof(Practica<float>));
				if (!entrada.eof())
				{
					maxPract->insert(pr,urgencia);
				}
			}
			entrada.close();
		}
		Console::Clear();
		cin.ignore(10000, '\n');
		cout << "Ingrese el nombre del puesto de practica que desea buscar: ";
		getline(cin, auxPr.puesto_practica);
		pos = maxPract->Busqueda(auxPr, name);
		if (maxPract->getTamanio() > 0)
		{
			while (finalizar == false)
			{
				pr = maxPract->getDato(pos);
				Console::Clear();
				cout << "------------------- " << pr.puesto_practica << " ------------------- " << endl;
				cout << "Nombre de la empresa: " << pr.empresa_practica << endl;
				cout << "Ubicaci�n: " << pr.ubicacion << endl;
				cout << "Descripci�n del puesto de trabajo: " << pr.descripcion << endl;
				cout << "Carrera del practicante solicitado: " << pr.carrera << endl;
				cout << "Ciclo m�nimo que esta cursando el practicante: " << pr.ciclo << endl;
				cout << "Remuneraci�n: " << pr.pago << endl;
				cout << "Urgencia de puesto: " << pr.urgencia << endl;
				cout << "-------------------------------------- " << endl;
				do
				{
					cout << "Elija una opci�n" << endl;
					cout << "1. Siguiente" << endl;
					cout << "2. Anterior" << endl;
					cout << "3. ordenar de mayor a menor segun remuneracion" << endl;
					cout << "4. ordenar de menor a mayor segun remuneracion" << endl;
					cout << "5. Salir de la busqueda de practicas laborales" << endl;
					cin >> op;
				} while (op > 5 || op < 1);
				switch (op)
				{
				case 1:
					if (pos < maxPract->getTamanio() - 1) {
						pos += 1;
					}
					break;
				case 2:
					if (pos > 0) {
						pos -= 1;
					}
					break;
				case 3:
					pos = 0;
					maxPract->Ordenamiento(1, valor);
					break;
				case 4:
					pos = 0;
					maxPract->Ordenamiento(2, valor);
					break;
				case 5:
					finalizar = true;
					delete maxPract;
					break;
				default:
					break;
				}

			}
		}
		else
		{
			cout << "Lista vacia" << endl;
			_getch();
		}
	}
	void buscarCurso() {
		ListaC = new ListaCurso();
		Nodo<Curso<float>>* aux = new Nodo<Curso<float>>();
		bool finalizar = false;
		int op;
		entrada.open("cursos.dat", ios::in | ios::binary);
		if (entrada.is_open()) {
			while (!entrada.eof())
			{
				entrada.read((char*)&c, sizeof(Curso<float>));
				if (!entrada.eof())
				{
					ListaC->agregarDatoCircular(c);
				}
			}
			entrada.close();
		}
		Console::Clear();
		cin.ignore(10000,'\n');
		cout << "Ingrese el titulo del curso que desea buscar: ";
		getline(cin, aux->dato.titulo);
		nodoC = ListaC->buscarNodo(aux);
		if (ListaC->hayElementos() == true)
		{
			while (finalizar == false)
			{
				c = nodoC->dato;
				Console::Clear();
				cout << "------------------- " << c.titulo << " ------------------- " << endl;
				cout << "Tema: " << c.tema << endl;
				cout << "Profesor: " << c.profesor << endl;
				cout << "Fecha de publicacion: " << c.fecha_publicacion << endl;
				cout << "Costo del curso: " << c.costo << endl;
				cout << "-------------------------------------- " << endl;
				do
				{
					cout << "Elija una opci�n" << endl;
					cout << "1. Siguiente" << endl;
					cout << "2. Anterior" << endl;
					cout << "3. ordenar de mayor a menor segun costo" << endl;
					cout << "4. ordenar de menor a mayor segun costo" << endl;
					cout << "5. Salir de la busqueda de curso" << endl;
					cin >> op;
				} while (op > 5 || op < 1);
				auto comparar = [](Curso<float> c1, Curso<float> c2, int i)-> bool { if (i == 2)return c1.costo > c2.costo; else return c1.costo < c2.costo; };
				switch (op)
				{
				case 1:
					nodoC = ListaC->NodoSiguiente(nodoC);
					break;
				case 2:
					nodoC = ListaC->NodoAnterior(nodoC);
					break;
				case 3:
					nodoC = ListaC->Ordenamiento(comparar,2);
					break;
				case 4:
					nodoC = ListaC->Ordenamiento(comparar,1);
					break;
				case 5:
					finalizar = true;
					delete ListaC;
					break;
				default:
					break;
				}

			}
		}
		else
		{
			cout << "Lista vacia" << endl;
			_getch();
		}
	}
	void buscarPersona() {
		Usuario auxU;
		int pos, op;
		bool finalizar = false;
		Console::Clear();
		cin.ignore(10000,'\n');
		cout << "Ingrese el nombre de la persona que desea buscar: ";
		getline(cin, auxU.nombre);
		pos = vectorU->buscarPersona(auxU);
		if (vectorU->getTamanio() != 0)
		{
			while (finalizar == false)
			{
				Console::Clear();
				auxU = vectorU->getUsuario(pos);
				cout << "-------------------" << auxU.nombre << "------------------ - " << endl;
				cout << "Edad: " << auxU.edad << endl;
				cout << "Profesi�n: " << auxU.profesion << endl;
				cout << "N�mero de contacto: " << auxU.telefono << endl;
				cout << "E-mail de contacto: " << auxU.correo << endl;
				cout << "-------------------------------------- " << endl;
				do
				{
					cout << "Elija una opci�n" << endl;
					cout << "1. Siguiente" << endl;
					cout << "2. Anterior" << endl;
					cout << "3. Agregar como amigo" << endl;
					cout << "4. Salir de la busqueda de persona" << endl;
					cin >> op;
				} while (op > 4 || op < 1);
				switch (op)
				{
				case 1:
					if (pos < vectorU->getTamanio() - 1) {
						pos += 1;
					}
					break;
				case 2:
					if (pos > 0)
					{
						pos -= 1;
					}
					break;
				case 3:
					salida.open(ArchNameAmigos, ios::out | ios::app);
					if (salida.is_open()) {
						salida << auxU.nombre << "|" << auxU.edad << "|" << auxU.profesion << "|" << auxU.telefono << "|" << auxU.correo << "|" << auxU.contrasena << '\n';
						salida.close();
					}
					else
					{
						cout << "ERROR" << endl;
					}
					break;
				case 4:
					finalizar = true;
					break;
				default:
					break;
				}
			}
		}
		else {
			cout << "Vector vac�o" << endl;
		}
	}
	void buscarProducto() {
		ListaP = new ListaProducto();
		NodoCircular<Producto<float>>* aux = new NodoCircular<Producto<float>>();
		bool finalizar = false;
		int op;
		entrada.open("producto.dat", ios::in | ios::binary);
		if (entrada.is_open()) {
			while (!entrada.eof())
			{
				entrada.read((char*)&p, sizeof(Producto<float>));
				if (!entrada.eof())
				{
					ListaP->agregarDato(p);
				}
			}
			entrada.close();
		}
		Console::Clear();
		cin.ignore(10000,'\n');
		cout << "Ingrese el titulo del curso que desea buscar: ";
		getline(cin,aux->dato.nombre_producto);
		nodoP = ListaP->buscarNodo(aux);
		if (ListaP->hayElementos() == true)
		{
			while (finalizar == false)
			{
				p = nodoP->dato;
				Console::Clear();
				cout << "------------------- " << p.nombre_producto << " ------------------- " << endl;
				cout << "Nombre de la empresa: " << p.nombre_empresa << endl;
				cout << "Descripcion: " << p.descripcion << endl;
				cout << "Costo del producto: " << p.costo << endl;
				cout << "-------------------------------------- " << endl;
				do
				{
					cout << "Elija una opci�n" << endl;
					cout << "1. Siguiente" << endl;
					cout << "2. ordenar de mayor a menor segun costo" << endl;
					cout << "3. ordenar de menor a mayor segun costo" << endl;
					cout << "4. Salir de la busqueda de producto" << endl;
					cin >> op;
				} while (op > 5 || op < 1);
				switch (op)
				{
				case 1:
					nodoP = ListaP->NodoSiguiente(nodoP);
					break;
				case 2:
					nodoP = ListaP->Ordenamiento(2);
					break;
				case 3:
					nodoP = ListaP->Ordenamiento(1);
					break;
				case 4:
					finalizar = true;
					delete ListaP;
					break;
				default:
					break;
				}

			}
		}
		else
		{
			cout << "Lista vacia" << endl;
			_getch();
		}
	}
	void buscarEvento() {
		ColaEV = new ColaEvento();
		Nodo<Evento>* aux = new Nodo<Evento>();
		bool finalizar = false;
		int op;
		entrada.open("evento.dat", ios::in | ios::binary);
		if (entrada.is_open()) {
			while (!entrada.eof())
			{
				entrada.read((char*)&ev, sizeof(Evento));
				if (!entrada.eof())
				{
					ColaEV->agregarDato(ev);
				}	
			}
			entrada.close();
		}
		Console::Clear();
		cout << "Ingrese el nombre del evento que desea buscar: ";
		cin >> aux->dato.nombre_evento;
		nodoEV = ColaEV->buscarNodo(aux);
		if (ColaEV->hayElementos() == true)
		{
			while (finalizar == false)
			{
				ev = nodoEV->dato;
				Console::Clear();
				cout << "------------------- " << ev.nombre_evento << " ------------------- " << endl;
				cout << "Tema: " << ev.tema << endl;
				cout << "Fecha: " << ev.fecha << endl;
				cout << "Direccion: " << ev.direccion << endl;
				cout << "Descripcion: " << ev.descripcion << endl;
				cout << "-------------------------------------- " << endl;
				do
				{
					cout << "Elija una opci�n" << endl;
					cout << "1. Siguiente" << endl;
					cout << "2. Anterior" << endl;
					cout << "3. Eliminar primer evento" << endl;
					cout << "4. Salir de la busqueda de evento" << endl;
					cin >> op;
				} while (op > 4 || op < 1);
				switch (op)
				{
				case 1:
					nodoEV = ColaEV->NodoSiguiente(nodoEV);
					break;
				case 2:
					nodoEV = ColaEV->NodoAnterior(nodoEV);
					break;
				case 3:
					if (ColaEV->colaVacia() == false)
					{
						nodoEV = ColaEV->EliminarEvento(nodoEV);
						salida.open("evento.dat", ios::out | ios::binary);
						if (salida.is_open()) {
							for (int i = 0; i < ColaEV->getTamanio(); i++)
							{
								ev = nodoEV->dato;
								salida.write((const char*)&ev, sizeof(Evento));
								nodoEV = ColaEV->NodoSiguiente(nodoEV);
							}
							salida.close();
							nodoEV = ColaEV->getPrimero(nodoEV);
						}
						else
						{
							cout << "ERROR" << endl;
						}
					}
					break;
				case 4:
					finalizar = true;
					delete ColaEV;
					break;
				default:
					break;
				}

			}
		}
		else
		{
			cout << "Lista vacia" << endl;
			_getch();
		}
	}
	void MostrarAmigos() {
		string linea;
		auto showSimple = [](Usuario a)-> void {cout << a.nombre << "--" << a.edad << " | "; };
		ht = new HashTable<Usuario, string>(20);
		entrada.open(ArchNameAmigos, ios::in);
		while (getline(entrada, linea, '\n')) {
			stringstream stream(linea);
			string aux;
			Usuario user;
			getline(stream, aux, '|');
			user.nombre = aux;
			getline(stream, aux, '|');
			user.edad = stoi(aux);
			getline(stream, aux, '|');
			user.profesion = aux;
			getline(stream, aux, '|');
			user.telefono = aux;
			getline(stream, aux, '|');
			user.correo = aux;
			getline(stream, aux, '|');
			user.contrasena = aux;
			HashEntity<Usuario, string>* a = new HashEntity<Usuario, string>(user, user.nombre+user.contrasena);
			ht->insert(*a);
		}
		entrada.close();
		Console::Clear();
		ht->print(showSimple);
	}

	Usuario getActivo() {
		return activo;
	}

	void reset() {
		vectorU->limpiar();
	}
};


